import re
from aiogram import Bot, Router, F, types
from aiogram.filters import CommandStart
from aiogram.fsm.context import FSMContext

from helper import *

router = Router()

@router.message(CommandStart())
async def cmd_start(message: types.Message):
    # регистрация пользователя в системе, тип не активный
    # await state.set_data({'username': message.from_user.username, 'name': message.from_user.full_name, 'user_id': message.from_user.id})
    return await message.answer(
        f'Привет, {message.from_user.full_name}.\n'
        f'Я твой бот, который поможет тебе узнать больше о своем магазине и увеличить выручку.\n'
        f'Давай познакомимися, пришли свой контакт',
        reply_markup=kb_get_contact(),
    )


@router.message(F.contact)
async def get_contact(message: types.Message):
    contact = message.contact
    if message.contact.user_id == message.from_user.id:
        await message.answer(f'Контакт получен, с вами свяжется менеджер!')
